import { type Issue, type InsertIssue, type Comment, type InsertComment } from "@shared/schema";
import fs from "fs";
import path from "path";

export interface IStorage {
  getIssues(): Promise<Issue[]>;
  getIssue(id: number): Promise<Issue | undefined>;
  createIssue(issue: InsertIssue, imageFile?: Express.Multer.File): Promise<Issue>;
  updateIssueStatus(id: number, status: Issue["status"]): Promise<Issue | undefined>;
  toggleUpvote(id: number): Promise<Issue | undefined>;
  getComments(issueId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
}

export class MemStorage implements IStorage {
  private issues: Map<number, Issue>;
  private comments: Map<number, Comment>;
  private issueId: number;
  private commentId: number;
  private userVotes: Map<number, Set<string>>;
  private uploadDir: string;

  constructor() {
    this.issues = new Map();
    this.comments = new Map();
    this.userVotes = new Map();
    this.issueId = 1;
    this.commentId = 1;
    this.uploadDir = path.join(process.cwd(), "uploads");

    // Create uploads directory if it doesn't exist
    if (!fs.existsSync(this.uploadDir)) {
      fs.mkdirSync(this.uploadDir, { recursive: true });
    }
  }

  async getIssues(): Promise<Issue[]> {
    return Array.from(this.issues.values());
  }

  async getIssue(id: number): Promise<Issue | undefined> {
    return this.issues.get(id);
  }

  async createIssue(insertIssue: InsertIssue, imageFile?: Express.Multer.File): Promise<Issue> {
    const id = this.issueId++;
    let imageUrl: string | undefined;

    if (imageFile) {
      // Save file with a unique name
      const ext = path.extname(imageFile.originalname);
      const filename = `issue-${id}${ext}`;
      fs.renameSync(imageFile.path, path.join(this.uploadDir, filename));
      imageUrl = `/uploads/${filename}`;
    }

    const issue: Issue = {
      id,
      ...insertIssue,
      status: "Reported",
      upvotes: 0,
      imageUrl: imageUrl,
    };

    this.issues.set(id, issue);
    this.userVotes.set(id, new Set());
    return issue;
  }

  async updateIssueStatus(id: number, status: Issue["status"]): Promise<Issue | undefined> {
    const issue = this.issues.get(id);
    if (!issue) return undefined;

    const updated = { ...issue, status };
    this.issues.set(id, updated);
    return updated;
  }

  async toggleUpvote(id: number): Promise<Issue | undefined> {
    const issue = this.issues.get(id);
    if (!issue) return undefined;

    const userId = Math.random().toString(36);
    const votes = this.userVotes.get(id) || new Set();

    let updatedUpvotes = issue.upvotes;
    if (votes.has(userId)) {
      votes.delete(userId);
      updatedUpvotes--;
    } else {
      votes.add(userId);
      updatedUpvotes++;
    }

    const updated = { ...issue, upvotes: updatedUpvotes };
    this.issues.set(id, updated);
    this.userVotes.set(id, votes);
    return updated;
  }

  async getComments(issueId: number): Promise<Comment[]> {
    return Array.from(this.comments.values()).filter(c => c.issueId === issueId);
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.commentId++;
    const comment: Comment = { id, ...insertComment };
    this.comments.set(id, comment);
    return comment;
  }
}

export const storage = new MemStorage();