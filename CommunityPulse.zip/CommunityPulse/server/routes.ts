import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertIssueSchema, insertCommentSchema, statuses } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import path from "path";
import express from "express";

// Configure multer for handling file uploads
const upload = multer({
  dest: 'uploads/',
  fileFilter: (_req, file, cb) => {
    // Accept only images
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG and GIF images are allowed.'));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve uploaded files
  app.use('/uploads', express.static('uploads'));

  app.get("/api/issues", async (_req, res) => {
    const issues = await storage.getIssues();
    res.json(issues);
  });

  app.get("/api/issues/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });

    const issue = await storage.getIssue(id);
    if (!issue) return res.status(404).json({ message: "Issue not found" });

    res.json(issue);
  });

  app.post("/api/issues", upload.single('image'), async (req, res) => {
    try {
      const result = insertIssueSchema.omit({ image: true }).safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ message: result.error.message });
      }

      const issue = await storage.createIssue(result.data, req.file);
      res.status(201).json(issue);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "An unexpected error occurred" });
      }
    }
  });

  app.patch("/api/issues/:id/status", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });

    const result = z.enum(statuses).safeParse(req.body.status);
    if (!result.success) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const issue = await storage.updateIssueStatus(id, result.data);
    if (!issue) return res.status(404).json({ message: "Issue not found" });

    res.json(issue);
  });

  app.post("/api/issues/:id/toggle-vote", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });

    const issue = await storage.toggleUpvote(id);
    if (!issue) return res.status(404).json({ message: "Issue not found" });

    res.json(issue);
  });

  app.get("/api/issues/:id/comments", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });

    const comments = await storage.getComments(id);
    res.json(comments);
  });

  app.post("/api/issues/:id/comments", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });

    const result = insertCommentSchema.safeParse({ ...req.body, issueId: id });
    if (!result.success) {
      return res.status(400).json({ message: result.error.message });
    }

    const comment = await storage.createComment(result.data);
    res.status(201).json(comment);
  });

  const httpServer = createServer(app);
  return httpServer;
}