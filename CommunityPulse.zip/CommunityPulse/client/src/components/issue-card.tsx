import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ThumbsUp, MapPin, Tag, MessageSquare } from "lucide-react";
import type { Issue } from "@shared/schema";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface IssueCardProps {
  issue: Issue;
}

export function IssueCard({ issue }: IssueCardProps) {
  const toggleVoteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/issues/${issue.id}/toggle-vote`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
    },
  });

  return (
    <Card>
      <CardHeader className="space-y-2">
        <div className="space-x-2">
          <Badge
            variant={
              issue.status === "Resolved"
                ? "default"
                : issue.status === "In Progress"
                ? "secondary"
                : "outline"
            }
          >
            {issue.status}
          </Badge>
        </div>
        <Link href={`/issues/${issue.id}`}>
          <a className="text-lg font-semibold hover:underline">
            {issue.description}
          </a>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-x-2">
            <Badge variant="outline" className="space-x-1">
              <MapPin className="h-3 w-3" />
              <span>{issue.location}</span>
            </Badge>
            <Badge variant="outline" className="space-x-1">
              <Tag className="h-3 w-3" />
              <span>{issue.category}</span>
            </Badge>
          </div>
          <div className="flex space-x-2">
            <Button
              variant={issue.upvotes > 0 ? "default" : "ghost"}
              size="sm"
              onClick={(e) => {
                e.preventDefault();
                toggleVoteMutation.mutate();
              }}
              disabled={toggleVoteMutation.isPending}
            >
              <ThumbsUp className="mr-2 h-4 w-4" />
              {issue.upvotes} votes
            </Button>
            <Link href={`/issues/${issue.id}`}>
              <Button variant="ghost" size="sm" asChild>
                <a>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Discuss
                </a>
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}