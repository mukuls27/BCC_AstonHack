import type { Issue } from "@shared/schema";
import { IssueCard } from "./issue-card";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface IssueGridProps {
  issues?: Issue[];
  isLoading: boolean;
}

function IssueCardSkeleton() {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="space-y-4">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-8 w-full" />
          <div className="space-x-2">
            <Skeleton className="h-5 w-24 inline-block" />
            <Skeleton className="h-5 w-24 inline-block" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function IssueGrid({ issues, isLoading }: IssueGridProps) {
  if (isLoading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <IssueCardSkeleton key={i} />
        ))}
      </div>
    );
  }

  if (!issues?.length) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          No issues reported yet.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {issues.map((issue) => (
        <IssueCard key={issue.id} issue={issue} />
      ))}
    </div>
  );
}
