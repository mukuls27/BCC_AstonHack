import { useQuery } from "@tanstack/react-query";
import type { Issue } from "@shared/schema";
import { IssueGrid } from "@/components/issue-grid";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { PlusCircle } from "lucide-react";

export default function Home() {
  const { data: issues, isLoading } = useQuery<Issue[]>({ 
    queryKey: ["/api/issues"]
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Community Issues</h1>
          <p className="text-lg text-muted-foreground mt-2">
            View and track local issues reported by your community
          </p>
        </div>
        <Link href="/report">
          <Button size="lg">
            <PlusCircle className="mr-2 h-5 w-5" />
            Report Issue
          </Button>
        </Link>
      </div>

      <IssueGrid issues={issues} isLoading={isLoading} />
    </div>
  );
}
