import { useQuery } from "@tanstack/react-query";
import type { Issue } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { statuses } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { MapPin, Tag } from "lucide-react";
import { BackButton } from "@/components/back-button";

export default function Admin() {
  const { data: issues, isLoading } = useQuery<Issue[]>({
    queryKey: ["/api/issues"],
  });

  const handleStatusChange = async (issueId: number, newStatus: string) => {
    await apiRequest("PATCH", `/api/issues/${issueId}/status`, { status: newStatus });
    queryClient.invalidateQueries({ queryKey: ["/api/issues"] });
  };

  if (isLoading) {
    return (
      <div>
        <BackButton />
        <div>Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <BackButton />
      <div>
        <h1 className="text-4xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-lg text-muted-foreground mt-2">
          Manage and update issue statuses
        </p>
      </div>

      <div className="space-y-4">
        {issues?.map((issue) => (
          <Card key={issue.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <CardTitle>{issue.description}</CardTitle>
                  <CardDescription className="space-x-2">
                    <Badge variant="outline" className="space-x-1">
                      <MapPin className="h-3 w-3" />
                      <span>{issue.location}</span>
                    </Badge>
                    <Badge variant="outline" className="space-x-1">
                      <Tag className="h-3 w-3" />
                      <span>{issue.category}</span>
                    </Badge>
                  </CardDescription>
                </div>
                <Select
                  value={issue.status}
                  onValueChange={(value) => handleStatusChange(issue.id, value)}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statuses.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {issue.upvotes} upvotes
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}