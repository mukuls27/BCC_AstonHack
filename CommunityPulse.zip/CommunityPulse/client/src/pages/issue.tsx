import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import type { Issue, Comment } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ThumbsUp, MapPin, Tag } from "lucide-react";
import { useState } from "react";
import { BackButton } from "@/components/back-button";

export default function Issue() {
  const { id } = useParams<{ id: string }>();
  const { toast } = useToast();
  const [comment, setComment] = useState("");

  const { data: issue, isLoading: isLoadingIssue } = useQuery<Issue>({
    queryKey: [`/api/issues/${id}`],
  });

  const { data: comments = [], isLoading: isLoadingComments } = useQuery<Comment[]>({
    queryKey: [`/api/issues/${id}/comments`],
  });

  const toggleVoteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/issues/${id}/toggle-vote`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/issues/${id}`] });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/issues/${id}/comments`, { content: comment });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/issues/${id}/comments`] });
      setComment("");
      toast({
        title: "Comment Added",
        description: "Your comment has been posted successfully.",
      });
    },
  });

  if (isLoadingIssue) {
    return (
      <div>
        <BackButton />
        <div>Loading...</div>
      </div>
    );
  }

  if (!issue) {
    return (
      <div>
        <BackButton />
        <div>Issue not found</div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <BackButton />
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl">{issue.description}</CardTitle>
              <CardDescription className="mt-2 space-x-4">
                <Badge variant="outline" className="space-x-1">
                  <MapPin className="h-3 w-3" />
                  <span>{issue.location}</span>
                </Badge>
                <Badge variant="outline" className="space-x-1">
                  <Tag className="h-3 w-3" />
                  <span>{issue.category}</span>
                </Badge>
              </CardDescription>
            </div>
            <Badge
              variant={
                issue.status === "Resolved"
                  ? "default"
                  : issue.status === "In Progress"
                  ? "secondary"
                  : "outline"
              }
            >
              {issue.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Button
            variant={issue.upvotes > 0 ? "default" : "ghost"}
            size="sm"
            onClick={() => toggleVoteMutation.mutate()}
            disabled={toggleVoteMutation.isPending}
          >
            <ThumbsUp className="mr-2 h-4 w-4" />
            {issue.upvotes} Upvotes
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Comments</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <Textarea
              placeholder="Add a comment..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
            <Button
              onClick={() => commentMutation.mutate()}
              disabled={!comment.trim() || commentMutation.isPending}
            >
              Post Comment
            </Button>
          </div>

          {isLoadingComments ? (
            <div>Loading comments...</div>
          ) : (
            <div className="space-y-4">
              {comments.map((comment) => (
                <Card key={comment.id}>
                  <CardContent className="pt-4">
                    {comment.content}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}