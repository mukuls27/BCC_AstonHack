import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const categories = [
  "Noise Pollution",
  "Damaged Property",
  "Street Lighting",
  "Road Maintenance",
  "Waste Management",
  "Public Safety",
  "Other"
] as const;

export const wards = [
  "Aston",
  "Bordesley Green",
  "Bournbrook",
  "Edgbaston",
  "Erdington",
  "Hall Green",
  "Handsworth",
  "Harborne",
  "Hodge Hill",
  "King's Heath",
  "Ladywood",
  "Moseley",
  "Nechells",
  "Perry Barr",
  "Selly Oak",
  "Small Heath",
  "Sparkbrook",
  "Sutton Coldfield",
  "Washwood Heath",
  "Yardley"
] as const;

export const statuses = ["Reported", "In Progress", "Resolved"] as const;

export const issues = pgTable("issues", {
  id: serial("id").primaryKey(),
  description: text("description").notNull(),
  category: text("category").notNull().$type<typeof categories[number]>(),
  location: text("location").notNull().$type<typeof wards[number]>(),
  status: text("status").notNull().$type<typeof statuses[number]>().default("Reported"),
  upvotes: integer("upvotes").notNull().default(0),
  imageUrl: text("image_url"),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  issueId: integer("issue_id").notNull(),
  content: text("content").notNull(),
});

export const insertIssueSchema = createInsertSchema(issues).pick({
  description: true,
  category: true,
  location: true,
}).extend({
  description: z.string().min(10).max(1000),
  category: z.enum(categories),
  location: z.enum(wards),
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  issueId: true,
  content: true,
}).extend({
  content: z.string().min(1).max(500),
});

export type Issue = typeof issues.$inferSelect;
export type InsertIssue = z.infer<typeof insertIssueSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;